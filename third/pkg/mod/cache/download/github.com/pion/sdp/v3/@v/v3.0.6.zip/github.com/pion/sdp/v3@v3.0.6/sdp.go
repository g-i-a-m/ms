// Package sdp implements Session Description Protocol (SDP)
package sdp
