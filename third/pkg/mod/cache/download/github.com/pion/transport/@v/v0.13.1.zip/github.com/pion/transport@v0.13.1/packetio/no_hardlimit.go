//go:build !packetioSizeHardlimit
// +build !packetioSizeHardlimit

package packetio

const sizeHardlimit = false
