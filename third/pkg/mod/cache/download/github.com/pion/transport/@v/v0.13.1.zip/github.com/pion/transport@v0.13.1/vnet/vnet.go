// Package vnet provides a virtual network layer for pion
package vnet
