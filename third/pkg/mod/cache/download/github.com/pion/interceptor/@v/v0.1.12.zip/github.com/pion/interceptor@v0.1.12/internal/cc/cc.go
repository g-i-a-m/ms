// Package cc implements common constructs used by Congestion Controllers
package cc
