//go:build !js
// +build !js

package webrtc
